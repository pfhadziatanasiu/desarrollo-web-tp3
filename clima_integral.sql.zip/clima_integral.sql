-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 11, 2026 at 06:01 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clima_integral`
--
CREATE DATABASE IF NOT EXISTS `clima_integral` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `clima_integral`;

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(254) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `name`, `last_name`, `email`, `phone`, `address`, `city`, `country`, `created_at`, `updated_at`) VALUES
(1, 'Juan', 'Pérez', 'juan.perez@example.com', '11 4567-8901', 'Av. Centenario 1234', 'San Isidro', 'Argentina', '2026-09-11 03:36:47', '2026-09-11 03:36:47'),
(2, 'María', 'Gómez', 'maria.gomez@example.com', '11 4321-5678', 'Av. Santa Fe 2450', 'Buenos Aires', 'Argentina', '2026-09-11 03:36:47', '2026-09-11 03:36:47'),
(3, 'Carlos', 'Rodríguez', 'carlos.rodriguez@example.com', '11 4789-1234', 'Av. Maipú 1850', 'Vicente López', 'Argentina', '2026-09-11 03:36:47', '2026-09-11 03:36:47'),
(4, 'Laura', 'Fernández', 'laura.fernandez@example.com', '11 4743-9876', '25 de Mayo 750', 'San Fernando', 'Argentina', '2026-09-11 03:36:47', '2026-09-11 03:36:47'),
(5, 'Diego', 'Martínez', 'diego.martinez@example.com', '11 4731-2468', 'Av. Cazón 1250', 'Tigre', 'Argentina', '2026-09-11 03:36:47', '2026-09-11 03:36:47'),
(6, 'Sofía', 'López', 'sofia.lopez@example.com', '11 4765-3344', 'Paraná 840', 'Martínez', 'Argentina', '2026-09-11 03:36:47', '2026-09-11 03:36:47'),
(7, 'Martín', 'Sánchez', 'martin.sanchez@example.com', '11 4798-5521', 'Italia 620', 'San Isidro', 'Argentina', '2026-09-11 03:36:47', '2026-09-11 03:36:47'),
(8, 'Valentina', 'Romero', 'valentina.romero@example.com', '11 4712-7789', 'Constitución 1450', 'San Fernando', 'Argentina', '2026-09-11 03:36:47', '2026-09-11 03:36:47'),
(9, 'Nicolás', 'Torres', 'nicolas.torres@example.com', '11 4749-6632', 'Av. del Libertador 980', 'Vicente López', 'Argentina', '2026-09-11 03:36:47', '2026-09-11 03:36:47'),
(10, 'Carolina', 'Álvarez', 'carolina.alvarez@example.com', '11 4725-1198', 'Chacabuco 530', 'Tigre', 'Argentina', '2026-09-11 03:36:47', '2026-09-11 03:36:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
